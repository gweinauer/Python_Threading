from Threading.source.cipher_thread import CipherThread


def encrypt(message, thread_number):
    thread_list = []
    begin = 0
    # Die Menge der Buchstaben festlegen, welche pro Thread bearbeitet wird
    work_size = int(len(message) / thread_number)
    end = work_size
    i = 0
    while i < thread_number:
        # Thread erstellen
        thread = CipherThread(i + 1, begin, end, message)
        thread_list.append(thread)
        # Thread starten -> run() ausführen
        thread.start()
        # Solange die übrigen Buchstaben die work_size entpricht (gleich oder größer)
        if begin < work_size:
            begin += work_size
            end += work_size
        else:
            begin += work_size
            # Übrige Buchstaben end hinzufügen -> Erreicht das ende von Message String
            end += len(message) % thread_number
            # Übrige Buchstaben dem letzten Thread zuweisen
            thread = CipherThread(i + 1, begin, end, message)
            thread_list.append(thread)
            thread.start()
        i += 1
    # Nachricht wieder Zusammenbauen
    encrypted_message = ""
    s = 0
    while s < len(thread_list):
        #Verschlüsselte Teilnachricht abfragen und der nachricht hinzufügen
        encrypted_message += thread_list[s].get_encrypted_message_divisor()
        s += 1
    return encrypted_message
    # ---------------------------


def decrypt(message, thread_number):
    thread_list = []
    begin = 0
    work_size = int(len(message) / thread_number)
    end = work_size
    i = 0
    while i < thread_number:
        thread = CipherThread(i + 1, begin, end, message)
        thread_list.append(thread)
        thread.start()
        if begin < work_size:
            begin += work_size
            end += work_size
        else:
            begin += work_size
            end += len(message) % thread_number
            thread = CipherThread(i + 1, begin, end, message)
            thread_list.append(thread)
            thread.start()
        i += 1
    decrypted_message = ""
    s = 0
    while s < len(thread_list):
        decrypted_message += thread_list[s].get_decrypted_message_divisor()
        s += 1
    return decrypted_message


allowed_input = False
while not allowed_input:
    message = input("Which message do you want to encrypt?")
    if all(x.isalpha() or x.isspace() for x in message):
        allowed_input = True
        message = message.lower()
    else:
        print("only Letters")
thread_number = int(input("How many threads should encrypt the message?"))
print("input: "+message)
print("encrypted: "+encrypt(message, thread_number))
print("decrypted: "+decrypt(message, thread_number))



