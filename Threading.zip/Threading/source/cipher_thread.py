import threading, time


class CipherThread(threading.Thread):
    """
    Diese Klasse stellt einen Thread dar,
    welcher bis zum vorgegebenen Wert
    hinaufzählt.

    :ivar int count_to: Zahl, bis zu welcher hinauf gezählt werden soll
    :ivar int thread_number: Nummer des Threads
    :param int count_to: Zahl, bis zu welcher hinauf gezählt werden soll
    :param int thread_number: Nummer des Threads
    """

    # Klassenvariable für die Anzahl an Threads
    __anzahl = 0

    def __init__(self, thread_number, begin, end, message):
        """
        Initialisiert die Superklasse und speichert
        die Parameter in die Instanzvariablen.

        :param thread_number: Nummer des neuen Threads
        :param count_to: Zahl, bis zu welcher hinauf gezählt werden soll
        """
        threading.Thread.__init__(self)
        self.dict = {"a": "z", "b": "y", "c": "x", "d": "v", "e": "u", "f": "t", "g": "s", "h": "r", "i": "q", "j": "p",
                     "k": "o", "l": "n", "m": "m", "n": "l", "o": "k", "p": "j", "q": "i", "r": "h", "s": "g", "t": "f",
                     "u": "e", "v": "d", "x": "c", "y": "b", "z": "a"}
        self.dict_decrypt = {"z": "a", "y": "b", "x": "c", "v": "d", "u": "e", "t": "f", "s": "g", "r": "h", "q": "i",
                             "p": "j","o": "k", "n": "l", "m": "m", "l": "n", "k": "o", "j": "p", "i": "q", "h": "r",
                             "g": "s", "f": "t", "e": "u", "d": "v", "c": "x", "b": "y", "a": "z"}
        self.substring = message[begin:end]
        self.thread_number = thread_number
        self.encrypted = ""
        self.decrypted = ""

    @classmethod
    def get_thread_anzahl(cls):
        """
        Liefert die Gesamtanzahl an Threads zurück.
        :return: Anzahl an erzeugten Threads
        """
        return cls.__anzahl

    def encrypt(self):
        s = 0
        while s < len(self.substring):
            if self.substring[s].isalpha():
                self.encrypted += self.dict[self.substring[s]]
            s += 1

    def decrypt(self):
        s = 0
        while s < len(self.encrypted):
            if self.encrypted[s].isalpha():
                self.decrypted += self.dict_decrypt[self.encrypted[s]]
            s += 1

    def get_encrypted_message_divisor(self):
        return self.encrypted

    def get_decrypted_message_divisor(self):
        return self.decrypted

    def run(self):
        """
        """
        self.encrypt()
        self.decrypt()
